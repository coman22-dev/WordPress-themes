const LicenseModal = () => {
  return <div>LicenseModal</div>;
};

export default LicenseModal;
