<?php return array('dependencies' => array('react', 'wp-element'), 'version' => '720c0fd4475799570ba6');
